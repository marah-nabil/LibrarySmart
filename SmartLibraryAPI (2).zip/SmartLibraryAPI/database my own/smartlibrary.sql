-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2025 at 05:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartlibrary`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `status`) VALUES
(1, 'Mockingbird', 'Lee12', 'BORROWED'),
(2, 'ggt', 'George Orwell', 'BORROWED'),
(3, 'Great Gatsby1', 'F. Scott', 'AVAILABLE'),
(4, 'Pride and Prejudice', 'Austen', 'AVAILABLE'),
(5, 'Catcher in the Rye', 'J.D', 'BORROWED'),
(6, 'java2', 'lab5', 'BORROWED'),
(8, 'Java3', 'Abdelkareem', 'BORROWED'),
(10, 'Helween book', 'American person', 'BORROWED'),
(11, 'fghjk', 'ghjkl;sldf', 'AVAILABLE'),
(12, 'bvcbv', 'hgfd', 'AVAILABLE');

-- --------------------------------------------------------

--
-- Table structure for table `borrowing`
--

CREATE TABLE `borrowing` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `borrow_date` date NOT NULL,
  `return_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrowing`
--

INSERT INTO `borrowing` (`id`, `book_id`, `member_id`, `borrow_date`, `return_date`) VALUES
(1, 1, 1, '2025-09-01', NULL),
(2, 4, 3, '2025-09-09', '2025-09-28'),
(3, 2, 4, '2025-09-23', NULL),
(4, 1, 3, '2025-09-28', '2025-09-28'),
(5, 5, 5, '2025-09-28', '2025-10-08'),
(6, 6, 2, '2025-09-02', NULL),
(7, 1, 4, '2025-09-28', '2025-09-28'),
(8, 8, 7, '2025-09-24', NULL),
(9, 10, 7, '2025-09-20', NULL),
(10, 11, 4, '2025-10-08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `contact`) VALUES
(1, 'Sarah', 'sarah.john@email.com'),
(2, 'Emily', 'emily.rod@email.com'),
(3, 'Wong', 'wong.thom@email.com'),
(4, 'Lisa2', 'lisa.123@mail.com'),
(5, 'Marah', 'Marah123@mail.com'),
(7, 'Layan', 'Layan@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `first_Name` varchar(50) NOT NULL,
  `last_Name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `first_Name`, `last_Name`, `password`) VALUES
(1, 'admin@library.com', 'Admin', 'User', '0192023a7bbd73250516f069df18b500'),
(2, 'mm@gmail.com', 'mm', 'mm', '202cb962ac59075b964b07152d234b70'),
(3, 'hp@gmail.com', 'hp', 'hp', '202cb962ac59075b964b07152d234b70'),
(4, 'Marahsal@gmail.com', 'Marah', 'sal', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `borrowing`
--
ALTER TABLE `borrowing`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_borrow_book` (`book_id`),
  ADD KEY `fk_borrow_member` (`member_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `borrowing`
--
ALTER TABLE `borrowing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrowing`
--
ALTER TABLE `borrowing`
  ADD CONSTRAINT `fk_borrow_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`),
  ADD CONSTRAINT `fk_borrow_member` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
