


package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.Borrowing;
import com.example.SmartLibraryAPI.reprository.BorrowingRepository;
import java.net.URI;
import java.net.http.HttpRequest;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/borrowing")
@CrossOrigin(origins = "*")
public class BorrowingApiController {
    
    
    @Autowired
    private BorrowingRepository repo;
    
    @GetMapping
    public List<Borrowing> getAll(){
        return repo.findAllWithDetails();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Borrowing> getRyId(@PathVariable int id){
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public Borrowing add(@RequestBody Borrowing b){
        return repo.save(b);
    }
    
    @PutMapping("/{id}/return")
    public ResponseEntity<Borrowing> update(@PathVariable int id,@RequestBody Borrowing upd){
        return repo.findById(id)
                .map(b -> {
                b.setReturnDate(upd.getReturnDate() != null ? upd.getReturnDate() : java.time.LocalDate.now());
                return ResponseEntity.ok(repo.save(b));
            })
            .orElse(ResponseEntity.notFound().build());
    }
    
    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id){
        repo.deleteById(id);
    
    }
    
    @GetMapping("/statistics")
    public String getStatistics(){
        long total = repo.count();
        long active =repo.findAll().stream().filter(b -> b.getReturnDate() == null).count();
        long returned = total - active;
        return String.format("""
                {
                  "totalBorrowed": "%d",                
                  "activeBorrowings": "%d",
                  "returned": "%d"
                }
            """, total, active, returned);
    }
    @GetMapping("/overdue")
    public List<Borrowing> getOverdueBorrowings(){
        return repo.findAll().stream()
                .filter(b -> b.getReturnDate() == null &&
                        b.getBorrowDate() != null && 
                        b.getBorrowDate().plusDays(14).isBefore(java.time.LocalDate.now()
                        )).toList();
    }
}
