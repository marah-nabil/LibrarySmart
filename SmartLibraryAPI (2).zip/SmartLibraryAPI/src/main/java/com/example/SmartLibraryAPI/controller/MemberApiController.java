/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.SmartLibraryAPI.controller;


import com.example.SmartLibraryAPI.model.Member;
import com.example.SmartLibraryAPI.reprository.MemberRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/members")
@CrossOrigin(origins = "*")
public class MemberApiController {
    
    @Autowired
    private MemberRepository repo;
    
    @GetMapping
    public List<Member> getAllMembers(){
        return repo.findAll();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Member> getMembers(@PathVariable int id){
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public Member addBook(@RequestBody Member member){
        return repo.save(member);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Member> updateMember(@PathVariable int id,@RequestBody Member updatedMember){
        return repo.findById(id)
                .map(member -> {
                member.setName(updatedMember.getName());
                member.setContact(updatedMember.getContact());
                return ResponseEntity.ok(repo.save(member));
            })
            .orElse(ResponseEntity.notFound().build());
    }
    
    @DeleteMapping("/{id}")
    public void deleteMember(@PathVariable int id){
        repo.deleteById(id);
    
    }
}
