
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.Book;
import com.example.SmartLibraryAPI.model.Member;
import com.example.SmartLibraryAPI.model.User;
import com.example.SmartLibraryAPI.reprository.BookRepository;
import com.example.SmartLibraryAPI.reprository.MemberRepository;
import com.example.SmartLibraryAPI.reprository.UserRepository;
import java.security.MessageDigest;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FileHandler {
    
    @Bean 
    CommandLineRunner initDatabase(UserRepository userRepo,
                                   BookRepository bookRepo,
                                   MemberRepository memberRepo){
     return args -> {
         if(userRepo.count() == 0){
             User admin = new User("Admin", "User", "admin@library.com", encryptPassword("admin123"));
             userRepo.save(admin);
             System.out.println("Default admin user created successfully.");
         }
         
         if (bookRepo.count() == 0) {
            System.out.println("No books found, adding defult sample books.");
            bookRepo.save(new Book("Mockingbird", "Lee", Book.Status.BORROWED));
            bookRepo.save(new Book("ggt", "George Orwell", Book.Status.AVAILABLE));
            bookRepo.save(new Book("Great Gatsby", "F. Scott", Book.Status.BORROWED));
            bookRepo.save(new Book("Pride and Prejudice", "Austen", Book.Status.AVAILABLE));
            bookRepo.save(new Book("Catcher in the Rye", "J.D", Book.Status.BORROWED));
            System.out.println("Default books added.");
        }
         if (memberRepo.count() == 0) {
            System.out.println("No books found, adding defult sample books.");
            memberRepo.save(new Member(0, "Sarah", "sarah.john@email.com"));
            memberRepo.save(new Member(0, "Emily", "emily.rod@email.com"));
            memberRepo.save(new Member(0, "Wong", "wong.thom@email.com"));
            memberRepo.save(new Member(0, "Lisa", "lisa.123@mail.com"));
            System.out.println("Default members added.");
        }
     };   
    }
   
    // MD5 encryption method
    public static String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes());
            byte[] bytes = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            System.err.println("Password encryption failed: " + e.getMessage());
            return password;
        }
    }
}