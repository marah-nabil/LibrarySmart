
package com.example.SmartLibraryAPI;


import javafx.application.Application;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartLibraryApiApplication {

	public static void main(String[] args) {
            
            Application.launch(JavaFxapp.class, args);
//		SpringApplication.run(SmartLibraryApiApplication.class, args);
//	try {
//            // JSON يمثل الكتاب الجديد
//            String json = """
//            {
//              "title": "Clean 2",
//              "author": "C. Martin",
//              "status": "borrowed"
//            }
//            """;
//
//            // إنشاء العميل
//            HttpClient client = HttpClient.newHttpClient();
//
//            // إعداد الطلب
//            HttpRequest request = HttpRequest.newBuilder()
//                    .uri(URI.create("http://localhost:8080/books"))
//                    .header("Content-Type", "application/json")
//                    .POST(HttpRequest.BodyPublishers.ofString(json))
//                    .build();
//
//            // إرسال الطلب واستلام الرد
//            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
//
//            // طباعة النتيجة في الكونسول
//            System.out.println("Response code: " + response.statusCode());
//            System.out.println("Response body: " + response.body());
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    
        }

}
