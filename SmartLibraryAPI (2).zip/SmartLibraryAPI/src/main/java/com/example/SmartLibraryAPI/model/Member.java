
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.model;

import jakarta.persistence.*;
import javafx.beans.property.*;

@Entity
@Table(name = "members")
public class Member {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
     private int id ;
    
    @Column(nullable = false)
     private String name;
    
    @Column(nullable = false)
    private String contact;

    public Member() { }

    public Member(int id, String name, String contact) {
        this.id = id;
        this.name = name;
        this.contact = contact;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }
 
    public String toFileString() {
        return getId() + "," + getName() + "," + getContact();
    }

    // JavaFX properties for table binding
    public IntegerProperty idProperty() {
        return new SimpleIntegerProperty(id);
    }

    public StringProperty nameProperty() {
        return new SimpleStringProperty(name);
    }

    public StringProperty contactProperty() {
        return new SimpleStringProperty(contact);
    }
}


//    private final IntegerProperty id;
//    private final StringProperty name;
//    private final StringProperty contact;
//
//    public Member() { this(0, "",""); }
//
//    public Member(String name, String contact) {
//        this(0, name,contact);
//    }
//
//    public Member(int id, String name, String contact) {
//        this.id = new SimpleIntegerProperty(id);
//        this.name = new SimpleStringProperty(name);
//        this.contact = new SimpleStringProperty(contact);
//    }
//
//    public int getId() {
//        return id.get();
//    }
//    public void setId(int id){ this.id.set(id); }
//    public IntegerProperty idProperty() { return id; }
//    
//    public String getName() {
//        return name.get();
//    }
//
//    public void setName(String name) {
//        this.name.set(name);
//    }
//
//    public String getContact() {
//        return contact.get();
//    }
//
//    public void setContact(String contact) {
//        this.contact.set(contact);
//    }
//    public StringProperty nameProperty() {    return name;  }
//    public StringProperty contactProperty() {    return contact;  }
//    public String toFileString() {
//        return getId() + "," + getName() + "," + getContact();
//    }
//
//}
