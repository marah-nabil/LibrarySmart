
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.controller;


import com.example.SmartLibraryAPI.model.User;
import com.google.gson.Gson;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import java.io.IOException;
import java.net.http.HttpClient;
import javafx.application.Platform;
import javafx.scene.layout.StackPane;
import org.springframework.stereotype.Component;

@Component
public class MainController {
    
    @FXML private BorderPane rootLayout;
    @FXML private ScrollPane contentScrollPane;
    @FXML private Label statusLabel;
    @FXML private Label userLabel;
    
    private User currentUser;
 
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = new Gson();
    
    private static final String USERS_API = "http://localhost:9090/users";
    private static final String BOOKS_API = "http://localhost:8080/books";
    private static final String MEMBERS_API = "http://localhost:8080/members";

    // Initialize method called by FXMLLoader
    @FXML
    public void initialize() {
        updateStatus("Application started");
        showLoginScreen();
    }
    
    
    // Show login screen
    public void showLoginScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            StackPane loginPane = loader.load();
            
            LoginController controller = loader.getController();
            controller.setMainController(this);
            
            contentScrollPane.setContent(loginPane);
            updateStatus("Please sign in to continue");
            userLabel.setText("Not signed in");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load login screen: " + e.getMessage());
        }
    }
    
    // Show registration screen
    public void showRegistrationScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/register.fxml"));
            VBox registerPane = loader.load();
            
            RegisterController controller = loader.getController();
            controller.setMainController(this);
            
            contentScrollPane.setContent(registerPane);
            updateStatus("Create a new account");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load registration screen: " + e.getMessage());
        }
    }
    
    // Show dashboard
    public void showDashboard() {
        if (currentUser == null) {
            showAlert(Alert.AlertType.WARNING, "Access Denied", "Please sign in first");
            showLoginScreen();
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/dashboard.fxml"));
            StackPane dashboardPane = loader.load();
            
            DashboardController controller = loader.getController();
            controller.setMainController(this);
            controller.initializeData(currentUser);
            
            contentScrollPane.setContent(dashboardPane);
            updateStatus("Dashboard loaded");
            userLabel.setText("Logged in as: " + currentUser.getFirstName() + " " + currentUser.getLastName());
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load dashboard: " + e.getMessage());
        }
    }
    
    // Show books management
    public void showBooksManagement() {
        if (currentUser == null) {
            showAlert(Alert.AlertType.WARNING, "Access Denied", "Please sign in first");
            showLoginScreen();
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/books.fxml"));
            VBox booksPane = loader.load();
            
            BooksController controller = loader.getController();
            controller.setMainController(this);
            
            contentScrollPane.setContent(booksPane);
            updateStatus("Books management loaded");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load books management: " + e.getMessage());
        }
    }
    
    // Show members management
    public void showMembersManagement() {
        if (currentUser == null) {
            showAlert(Alert.AlertType.WARNING, "Access Denied", "Please sign in first");
            showLoginScreen();
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/members.fxml"));
            VBox membersPane = loader.load();
            
            MembersController controller = loader.getController();
            controller.setMainController(this);
            
            contentScrollPane.setContent(membersPane);
            updateStatus("Members management loaded");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load members management: " + e.getMessage());
        }
    }
    
    // Show borrowing management
    public void showBorrowingManagement() {
        if (currentUser == null) {
            showAlert(Alert.AlertType.WARNING, "Access Denied", "Please sign in first");
            showLoginScreen();
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/borrowing.fxml"));
            VBox borrowingPane = loader.load();
            
            BorrowingController controller = loader.getController();
            controller.setMainController(this);
            
            contentScrollPane.setContent(borrowingPane);
            updateStatus("Borrowing management loaded");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load borrowing management: " + e.getMessage());
        }
    }
    
    public void showReports(){
        if(currentUser == null){
            showAlert(Alert.AlertType.WARNING,"Access Denied","Please sing in first");
            showLoginScreen();
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/reports.fxml"));
            VBox reportsPane = loader.load();
            
            ReportsController controller = loader.getController();
            controller.setMainController(this);
            
            contentScrollPane.setContent(reportsPane);
            updateStatus("Reports page loaded");
            
        }catch (IOException e){
            showAlert(Alert.AlertType.ERROR, "ERROR", "Failed to load reports page: "+e.getMessage());
        }
    }
    // Handle menu actions
    @FXML
    private void handleExit() {
        System.exit(0);
    }
    
    @FXML
    private void handleSignOut() {
        currentUser = null;
        showLoginScreen();
        updateStatus("Signed out successfully");
    }
    
    @FXML
    private void handleAbout() {
        showAlert(Alert.AlertType.INFORMATION, "About", 
            "Smart Library Manager\nVersion 5.0 (Spring Boot Integration)\n\nJavaFX client connected to REST API.");
    }
    
    // Update status bar
    public void updateStatus(String message) {
        if (statusLabel != null) {
            Platform.runLater(() -> statusLabel.setText(message));
        }
    }
    
    // Show alert dialog
    public void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    // Getters and setters
    public User getCurrentUser() {
        return currentUser;
    }
    
    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }
    
    
}