
package com.example.SmartLibraryAPI;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;


public class JavaFxapp extends Application{

    private ConfigurableApplicationContext springContext;

    @Override
    public void stop() {
        springContext.close(); 
    }

    @Override
    public void init() throws Exception {
        springContext = new SpringApplicationBuilder(SmartLibraryApiApplication.class).run();
    }
    
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/main.fxml"));
        
        loader.setControllerFactory(springContext::getBean);
        
        Scene scene = new Scene(loader.load());
        scene.getStylesheets().add(getClass().getResource("/style/application.css").toExternalForm());
        stage.setTitle("Smart Library Manager");
        stage.setScene(scene);
        stage.show();
    
    }
    
}
