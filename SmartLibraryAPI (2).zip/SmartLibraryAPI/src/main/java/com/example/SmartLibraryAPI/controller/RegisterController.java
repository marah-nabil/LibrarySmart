
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import org.springframework.stereotype.Component;

@Component
public class RegisterController {
    
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    
    private MainController mainController;
    
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = new Gson();
    
    private static final String USERS_API = "http://localhost:9090/users";

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }
    
    @FXML
    private void handleRegister() {
        String first_Name = firstNameField.getText().trim();
        String last_Name = lastNameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();
        String confirmPassword = confirmPasswordField.getText().trim();
        
        // التحقق من الحقول الفارغة
        if (first_Name.isEmpty() || last_Name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            mainController.showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields!");
            return;
        }
        
        // التحقق من تطابق كلمات المرور
        if (!password.equals(confirmPassword)) {
            mainController.showAlert(Alert.AlertType.ERROR, "Error", "Passwords do not match!");
            return;
        }
        
        try{

            HttpRequest getReq = HttpRequest.newBuilder()
                        .uri(URI.create(USERS_API))
                        .GET()
                        .build();

            HttpResponse<String> getRes = httpClient.send(getReq, HttpResponse.BodyHandlers.ofString());            
            List<User> existingUsers = gson.fromJson(getRes.body(), new TypeToken<List<User>>(){}.getType());

            // التحقق من البريد الإلكتروني المستخدم مسبقاً
            boolean exists = existingUsers.stream().anyMatch(u -> u.getEmail().equalsIgnoreCase(email));
            if (exists) {
                    mainController.showAlert(Alert.AlertType.ERROR, "Error", "Email already registered!");
                    return;
            }
        
            // إنشاء مستخدم جديد
            String passwordHash = FileHandler.encryptPassword(password);
            String json = String.format("""
                {
                  "firstName": "%s", 
                  "lastName": "%s",                
                  "email": "%s",                
                  "passwordHash": "%s",
                }
            """, first_Name,last_Name,email,passwordHash);
            
            HttpRequest postReq = HttpRequest.newBuilder()
                    .uri(URI.create(USERS_API))
                    .header("Content-Type", "Application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            
            HttpResponse<String> postRes = httpClient.send(postReq, HttpResponse.BodyHandlers.ofString());

            if(postRes.statusCode() == 200 || postRes.statusCode() == 201){
                mainController.showAlert(Alert.AlertType.INFORMATION, "Success", "Account created successfully!");
                mainController.showLoginScreen();
            }else{
                mainController.showAlert(Alert.AlertType.ERROR, "ERROR", "Failed to register! ("+postRes.statusCode()+")");
            }
        }catch(Exception e){
            e.printStackTrace();
            mainController.showAlert(Alert.AlertType.ERROR, "ERROR", "Cannot connect to the API!");

        }
    }
    
    @FXML
    private void handleShowLogin() {
        mainController.showLoginScreen();
    }
}