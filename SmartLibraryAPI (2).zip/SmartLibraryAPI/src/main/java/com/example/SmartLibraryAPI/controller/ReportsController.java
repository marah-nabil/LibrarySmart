
package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.Book;
import com.example.SmartLibraryAPI.model.Borrowing;
import com.example.SmartLibraryAPI.model.Member;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.stereotype.Component;



@Component
public class ReportsController {
    @FXML private ComboBox<String> reportTypeCombo;
    @FXML private TextArea reportArea;

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = new GsonBuilder()
            .registerTypeAdapter(LocalDate.class, new LocalDateAdapter()).create();
    private MainController mainController;

    private static final String BORROWINGS_API = "http://localhost:9090/borrowing";
    private static final String OVERDUE_API = "http://localhost:9090/borrowing/overdue";
    private static final String STATISTICS_API = "http://localhost:9090/borrowing/statistics";

        
    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    @FXML
    public void initialize() {
        reportTypeCombo.getItems().addAll("Overdue Books", "Borrowing Statistics");
    }
    @FXML
    private void handleGenerateReport(){
        String selected = reportTypeCombo.getValue();
        if(selected == null){
            showAlert("Please select a report type");
            return;
        }
        
        Task<String> task = new Task<String>(){
        
            @Override
            protected String call() throws Exception{
                if(selected.equals("Overdue Books")){
                    return generateOverdueReport();
                }else if(selected.equals("Borrowing Statistics")){
                    return generateStatisticsReport();
                }
            return "Unknown report type.";

            }
        };
        task.setOnSucceeded(e -> reportArea.setText(task.getValue()));
        task.setOnFailed(e -> showAlert("Error generateing reoprt: "+ task.getException().getMessage()));
        
        new Thread(task).start();
    }
    
    private String generateOverdueReport(){
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(OVERDUE_API))
                    .header("Content-Type", "Application/json")
                    .GET()
                    .build();
            
            HttpResponse<String> response =httpClient.send(request, HttpResponse.BodyHandlers.ofString());
       
            JsonElement json = JsonParser.parseString(response.body());
            List<Borrowing> borrowings = new ArrayList<>();

            if(json.isJsonArray()){
                borrowings = gson.fromJson(json, new TypeToken<List<Borrowing>>(){}.getType());
            }else if (json.isJsonObject()){
                Borrowing single = gson.fromJson(json, Borrowing.class);
                borrowings.add(single);
            }              
            StringBuilder report = new StringBuilder("Overdue Books Report\n\n");
            
            if(borrowings == null || borrowings.isEmpty()){
                report.append("No Overdue Books");
                return report.toString();
            }
            for(Borrowing br: borrowings){
                Book book = br.getBook();
                Member member = br.getMember();
                LocalDate borrowDate = br.getBorrowDate();
                long days = ChronoUnit.DAYS.between(borrowDate, LocalDate.now());
                double fine = (days-14)* 1.0;
                
                report.append("Book: ").append(book != null ? book.getTitle() : "Unknown")
                            .append("| Borrowed by: ").append(member != null ? member.getName(): "Unknown")
                            .append(" | Days Overdue: ").append(days-14)
                            .append(" | Fine: $").append(fine).append("\n");

            }
            return report.toString();
            
        }catch(Exception e){
            e.printStackTrace();
            return "Error retrieving overdue report: "+e.getMessage();
        }
    }
     private String generateStatisticsReport(){
       try{
           HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(STATISTICS_API))
                    .header("Content-Type", "Application/json")
                    .GET()
                    .build();
            
            HttpResponse<String> response =httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            
            if(response.body().startsWith("Borrowing Statistics")){
                return response.body();
            }
            JsonElement json = JsonParser.parseString(response.body());

            if(json.isJsonObject()){
                Map<String, Object> stats = gson.fromJson(response.body(), new TypeToken<Map<String, Object>>(){}.getType());
                return "Borrowing Statistics\n\n"+
                    "Total Borrowing: "+ stats.getOrDefault("totalBorrowed",0L)+ "\n"+
                    "Active Borrowing: "+ stats.getOrDefault("activeBorrowings",0L)+ "\n"+
                    "Returned Borrowing: "+ stats.getOrDefault("returned",0L)+ "\n";
            }else{ 
                return "Invalied statistics format received from API";
            }
            }catch(Exception e){
            e.printStackTrace();
            return "Error retrieving statistics report: "+e.getMessage();
        }
    }
         // Show alert dialog
    public void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR,message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
    
}
