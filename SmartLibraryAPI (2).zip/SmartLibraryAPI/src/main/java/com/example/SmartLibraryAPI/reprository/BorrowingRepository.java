
package com.example.SmartLibraryAPI.reprository;

import com.example.SmartLibraryAPI.model.Borrowing;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface BorrowingRepository extends JpaRepository<Borrowing, Integer>{

    @Query("SELECT b FROM Borrowing b JOIN FETCH b.book JOIN FETCH b.member")
    List<Borrowing> findAllWithDetails();
}
