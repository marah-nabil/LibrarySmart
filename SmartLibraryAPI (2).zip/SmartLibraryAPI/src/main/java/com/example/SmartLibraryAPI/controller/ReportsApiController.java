//
//
//
//package com.example.SmartLibraryAPI.controller;
//
//import com.example.SmartLibraryAPI.reprository.BorrowingRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//
//
//@RestController
//@RequestMapping("/reports")
//@CrossOrigin(origins = "*")
//public class ReportsApiController {
//    
//    
//    @Autowired
//    private BorrowingRepository repo;
//    
//    @GetMapping
//    public String getStats(){
//        long total = repo.count();
//        long active =repo.findAll().stream().filter(b -> b.getReturnDate() == null).count();
//        return String.format("{\"total\":%d,\"active\":%d}", total, active);
//    }
//  
//}
