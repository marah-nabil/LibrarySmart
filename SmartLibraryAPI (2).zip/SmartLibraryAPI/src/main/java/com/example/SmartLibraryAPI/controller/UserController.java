


package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.User;
import com.example.SmartLibraryAPI.reprository.UserRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserRepository repo;

    @GetMapping
    public List<User> getAllUsers() {
        return repo.findAll();
    }
}
