
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.beans.property.*;

@Entity
@Table(name = "borrowing")
public class Borrowing {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "book_id" , nullable = false)
    private Book book;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "member_id" , nullable = false)
    private Member member;
    
    @Column(name = "borrow_date" ,nullable = false)
    private LocalDate borrowDate;
    
    @Column(name = "return_date")
    private LocalDate returnDate;

    @PrePersist
    public void prePersist(){
        if(borrowDate == null){
            borrowDate = LocalDate.now();
        }
    }
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;

    public Borrowing() {}

    public Borrowing(Book book, Member member, LocalDate borrowDate, LocalDate returnDate) {
        this.book = book;
        this.member = member;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

    // Getters and setters
    public int getId() {    return id;}
    public void setId(int id) {     this.id = id; }
    
    public Book getBook() {   return book;}
    public void setBook(Book book) {  this.book = book; }

    public Member getMember() {   return member; }
    public void setMember(Member member) {  this.member = member; }

    public LocalDate getBorrowDate() {   return borrowDate;}
    public void setBorrowDate(LocalDate borrowDate) {      this.borrowDate = borrowDate;   }

    public LocalDate getReturnDate() {   return returnDate; }
    public void setReturnDate(LocalDate returnDate) {     this.returnDate = returnDate;  }

    public String toFileString() {
        String returnDateStr = (returnDate == null) ? "null" : returnDate.format(DATE_FORMATTER);
        return id + "," + (book != null ? book.getTitle() : "null") + "," +
                (member != null ? member.getName() : "null") + "," +
                borrowDate.format(DATE_FORMATTER) + "," + returnDateStr;
    }

    // JavaFX properties for table binding
    public SimpleIntegerProperty idProperty() {
        return new SimpleIntegerProperty(id);
    }

    public SimpleStringProperty bookTitleProperty() {
        return new SimpleStringProperty(book != null ? book.getTitle() : "Unknown Book");
    }

    public SimpleStringProperty memberNameProperty() {
        return new SimpleStringProperty(member != null ? member.getName() : "Unknown Member");
    }

    public SimpleObjectProperty<LocalDate> borrowDateProperty() {
        return new SimpleObjectProperty<>(borrowDate);
    }

    public SimpleObjectProperty<LocalDate> returnDateProperty() {
        return new SimpleObjectProperty<>(returnDate);
    }
}

//    private final IntegerProperty id;    
//    private final ObjectProperty<Book> book;
//    private final ObjectProperty<Member> member;
//    private final ObjectProperty<LocalDate> borrowDate;
//    private final ObjectProperty<LocalDate> returnDate;
//
//
//
//    public Borrowing() { this(0, null ,null ,LocalDate.now(), null); }
//
//    public Borrowing(Book book, Member member, LocalDate borrowDate, LocalDate returnDate) {
//        this(0, book ,member ,borrowDate, returnDate);
//    }
//
//    public Borrowing(int id, Book book, Member member, LocalDate borrowDate, LocalDate returnDate) {
//        this.id = new SimpleIntegerProperty(id);
//        this.book = new SimpleObjectProperty<>(book);
//        this.member = new SimpleObjectProperty<>(member);
//        this.borrowDate = new SimpleObjectProperty<>(borrowDate);
//        this.returnDate = new SimpleObjectProperty<>(returnDate);
//    }
//
//
//    public int getId() {
//        return id.get();
//    }
//    public void setId(int id){ this.id.set(id); }
//    public IntegerProperty idProperty() { return id; }
//    
//    public Book getBook() {   return book.get();}
//    public void setBook(Book book) {  this.book.set(book); }
//
//    public Member getMember() {   return member.get(); }
//    public void setMember(Member member) {  this.member.set(member); }
//
//    public LocalDate getBorrowDate() {   return borrowDate.get();}
//    public void setBorrowDate(LocalDate borrowDate) {  this.borrowDate.set(borrowDate);   }
//
//    public LocalDate getReturnDate() {   return returnDate.get(); }
//    public void setReturnDate(LocalDate returnDate) {     this.returnDate.set(returnDate);  }
//
//    public ObjectProperty<Book> bookProperty() {
//        return book;
//    }
//    public ObjectProperty<Member> memberProperty() {
//        return member;
//    }
//    public ObjectProperty<LocalDate> borrowDateProperty() {
//        return borrowDate;
//    }
//
//    public ObjectProperty<LocalDate> returnDateProperty() {
//        return returnDate;
//    }
//    
//    @Override
//    public String toString() {
//        return String.format("Borrowing{id=%d, book=%s, member=%s, borrowDate=%s, returnDate=%s}",
//               getId(),
//               getBook() != null ? getBook().getTitle() : "N/A",
//               getMember() != null ? getMember().getName() : "N/A",
//               getBorrowDate(),
//               getReturnDate() != null ? getReturnDate() : "Not returned");
//
//    }
//
//}
