
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import org.springframework.stereotype.Component;

@Component
public class LoginController {
    
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    
    private MainController mainController;
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = new Gson();
    
    private static final String USERS_API = "http://localhost:9090/users";
   
    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }
    
    @FXML
    private void handleLogin() {
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();
        
        // التحقق من الحقول الفارغة
        if (email.isEmpty() || password.isEmpty()) {
            mainController.showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields!");
            return;
        }
         try{

            HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(USERS_API))
                        .GET()
                        .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());            
            List<User> users = gson.fromJson(response.body(), new TypeToken<List<User>>(){}.getType());
        
            User foundUser = users.stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(email))
                .findFirst().orElse(null);

            if(foundUser == null){
                mainController.showAlert(Alert.AlertType.ERROR, "Error", "No user found with this email");
                return;
            }
               
            String encryptedPassword = FileHandler.encryptPassword(password);
            if(!foundUser.getPassword().equals(encryptedPassword)){
                mainController.showAlert(Alert.AlertType.ERROR, "Error", "Incorrect Passwored");
                return;
                
            } 
            mainController.setCurrentUser(foundUser);
            mainController.showDashboard();
        }catch (Exception ex) {
            ex.printStackTrace();
            mainController.showAlert(Alert.AlertType.ERROR, "Connection Error", "Cannot connect to API!");
        }
    }
    
    @FXML
    private void handleShowRegister() {
        mainController.showRegistrationScreen();
    }
}