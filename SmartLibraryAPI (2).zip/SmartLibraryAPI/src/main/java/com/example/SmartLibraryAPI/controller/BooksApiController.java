

package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.Book;
import com.example.SmartLibraryAPI.reprository.BookRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/books")
@CrossOrigin(origins = "*")
public class BooksApiController {
        
    @Autowired
    private BookRepository repo;
    
    @GetMapping
    public List<Book> getAllBooks(){
        return repo.findAll();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBooks(@PathVariable int id){
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public Book addBook(@RequestBody Book book){
        return repo.save(book);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable int id,@RequestBody Book updatedBook){
        return repo.findById(id)
                .map(book -> {
                book.setTitle(updatedBook.getTitle());
                book.setAuthor(updatedBook.getAuthor());
                book.setStatus(updatedBook.getStatus());
                return ResponseEntity.ok(repo.save(book));
            })
            .orElse(ResponseEntity.notFound().build());
    }
    
    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable int id){
        repo.deleteById(id);
    
    }
}
