
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.Book;
import com.example.SmartLibraryAPI.model.Borrowing;
import com.example.SmartLibraryAPI.model.Member;
import com.example.SmartLibraryAPI.model.User;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import java.util.List;
import javafx.application.Platform;
import org.springframework.stereotype.Component;


@Component
public class DashboardController {
    
    @FXML private Label welcomeLabel;
    @FXML private Label totalBooksLabel;
    @FXML private Label availableBooksLabel;
    @FXML private Label membersLabel;
    @FXML private Label borrowingsLabel;
    
    @FXML private VBox totalBooksBox;
    @FXML private VBox availableBooksBox;
    @FXML private VBox membersBox;
    @FXML private VBox borrowingsBox;
    
    @FXML private Button goToBooksButton;
    @FXML private Button goToReadersButton;
    @FXML private Button goToBorrowingButton;
    @FXML private Button signOutButton;
    
    private MainController mainController;
    private User currentUser;
   
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = LocalDateAdapter.buildGson();
    
    private static final String API_URL = "http://localhost:9090/borrowing";
    private static final String BOOKS_API = "http://localhost:9090/books";
    private static final String MEMBERS_API = "http://localhost:9090/members";


    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }
    
    public void initializeData(User currentUser) {
        this.currentUser = currentUser;
        welcomeLabel.setText("Welcom, "+ currentUser.getFirstName()+ " "+ currentUser.getLastName()+ " !");
        refreshDashboardData();
    }
    
    @FXML
    public void initialize() {
        // Set up button actions
        goToBooksButton.setOnAction(e -> handleGoToBooks());
        goToReadersButton.setOnAction(e -> handleGoToMembers());
        goToBorrowingButton.setOnAction(e -> handleGoToBorrowing());
        signOutButton.setOnAction(e -> handleSignOut());
    }
    
    private void refreshDashboardData() {
        new Thread(() -> {
            try {
                //تحميل الكتب والاعضاء والاستعارات
             HttpRequest booksReq = HttpRequest.newBuilder()
                        .uri(URI.create(BOOKS_API))
                        .GET()
                        .build();

            HttpResponse<String> booksRes = httpClient.send(booksReq, HttpResponse.BodyHandlers.ofString());            
            List<Book> books = gson.fromJson(booksRes.body(), new TypeToken<List<Book>>(){}.getType());

            HttpRequest membersReq = HttpRequest.newBuilder()
                        .uri(URI.create(MEMBERS_API))
                        .GET()
                        .build();
            HttpResponse<String> membersRes = httpClient.send(membersReq, HttpResponse.BodyHandlers.ofString());
            List<Member> members = gson.fromJson(membersRes.body(), new TypeToken<List<Member>>(){}.getType());

             HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(API_URL))
                        .GET()
                        .build();
            HttpResponse<String> response = httpClient.send(req, HttpResponse.BodyHandlers.ofString());            
            
            //
            JsonElement json = JsonParser.parseString(response.body());
            List<Borrowing> borrowings = new ArrayList<>();
            
            if(json.isJsonArray()){
                borrowings = gson.fromJson(json, new TypeToken<List<Borrowing>>(){}.getType());
            }else if (json.isJsonObject()){
                Borrowing single = gson.fromJson(json, Borrowing.class);
                borrowings.add(single);
            }
            //حساب الاحصائيات 
            long totalBooks = books.size();
            long availableBooksCount = books.stream().filter(b -> b.getStatus() == Book.Status.AVAILABLE).count();
            long totalMembers = members.size();
            long activeBorrowings = borrowings.stream().filter(b -> b.getReturnDate() == null).count();

            //تحديث الواجهة
                Platform.runLater(() -> {
                    // Update statistics labels
                    totalBooksLabel.setText(String.valueOf(totalBooks));
                    availableBooksLabel.setText(String.valueOf(availableBooksCount));
                    membersLabel.setText(String.valueOf(totalMembers));
                    borrowingsLabel.setText(String.valueOf(activeBorrowings));

                });

            }catch(Exception e){
                e.printStackTrace();
                Platform.runLater(() -> {
                    totalBooksLabel.setText("-");
                    availableBooksLabel.setText("-");
                    membersLabel.setText("-");
                    borrowingsLabel.setText("-");

                });
            }
        }).start();
        
    }
    
    private void setupStatBoxHoverEffects() {
        // Add hover effects to make the UI more interactive
        totalBooksBox.setOnMouseEntered(e -> totalBooksBox.setStyle("-fx-cursor: hand;"));
        
        availableBooksBox.setOnMouseEntered(e -> availableBooksBox.setStyle(" -fx-cursor: hand;"));
        
        membersBox.setOnMouseEntered(e -> membersBox.setStyle("-fx-cursor: hand;"));
        
        borrowingsBox.setOnMouseEntered(e -> borrowingsBox.setStyle("-fx-cursor: hand;"));
        
        // Make stat boxes clickable
        totalBooksBox.setOnMouseClicked(e -> handleGoToBooks());
        membersBox.setOnMouseClicked(e -> handleGoToMembers());
        borrowingsBox.setOnMouseClicked(e -> handleGoToBorrowing());
    }
    
    @FXML
    private void handleGoToBooks() {
        mainController.showBooksManagement();
    }
    
    @FXML
    private void handleGoToMembers() {
        mainController.showMembersManagement();
    }
    
    @FXML
    private void handleGoToBorrowing() {
        mainController.showBorrowingManagement();
    }
    
    @FXML
    private void handleSignOut() {
        mainController.setCurrentUser(null);
        mainController.showLoginScreen();
    }
    
    // Method to refresh dashboard data
    public void refreshData() {
        refreshDashboardData();
    }
}
