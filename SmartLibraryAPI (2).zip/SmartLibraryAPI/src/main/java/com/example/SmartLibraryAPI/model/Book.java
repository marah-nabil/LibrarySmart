
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.model;


import jakarta.persistence.*;
import java.util.Objects;
import javafx.beans.property.*;

@Entity
@Table(name = "books")
public class Book {
   
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Column(nullable = false)
    private String title;
    @Column(nullable = false)
    private String author;
    public enum Status { AVAILABLE , BORROWED }
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, name = "status")
    private Status status;

    public Book() {}

    public Book(String title, String author, Status status) {
        this.title = title;
        this.author = author;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
    
   
    public String toFileString() {
        return getId() + "," + getTitle() + "," + getAuthor() + "," + getStatus();
    }

    // JavaFX properties for table binding
    public IntegerProperty idProperty() {
        return new SimpleIntegerProperty(id);
    }

    public StringProperty titleProperty() {
        return new SimpleStringProperty(title);
    }

    public StringProperty authorProperty() {
        return new SimpleStringProperty(author);
    }

    public ObjectProperty<Status> statusProperty() {
        return new SimpleObjectProperty<>(status);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Book)) {
            return false;
        }
        return getId() == ((Book) obj).getId();
    }
    
    public static Status parseStatus(String parts) {
        if(parts == null) return Status.AVAILABLE;
        String v = parts.trim().toLowerCase();
       
        switch (v) {
            case "available":
            case "avail":
            case "a":
                    return  Status.AVAILABLE;
            case "borrowed":
            case "borrow":
            case "b":
                    return Status.BORROWED;
            default :
                try { 
                    return Status.valueOf(parts.trim().toUpperCase()); 
                }catch(Exception e) { 
                    return Status.AVAILABLE; 
                }
            
        }
    }
}
//    public enum Status { 
//        @SerializedName("available")
//        AVAILABLE , 
//        @SerializedName("borrowed")
//        BORROWED 
//    }
//
//    private final IntegerProperty id;
//    private final StringProperty title;
//    private final StringProperty author;
//    private final ObjectProperty<Status> status;
//
//    public Book(){
//        this(0, "","",Status.AVAILABLE);
//    }
//
//    public Book(String title, String author, Status status) {
//        this(0, title, author, status);
//
//    }
//
//    public Book(int id,String title, String author, Status status) {
//        this.id = new SimpleIntegerProperty(id);
//        this.title = new SimpleStringProperty(title);
//        this.author = new SimpleStringProperty(author);
//        this.status = new SimpleObjectProperty<>(status);
//    }
//
//    public int getId() {
//        return id.get();
//    }
//    public void setId(int id){ this.id.set(id); }
//    public IntegerProperty idProperty() { return id; }
//    
//    public String getTitle() { return title.get(); }
//    public void setTitle(String title) { this.title.set(title); }
//
//    public String getAuthor() {
//        return author.get();
//    }
//
//    public void setAuthor(String author) {
//        this.author.set(author);
//    }
//
//    public Status getStatus() {
//        return status.get();
//    }
//
//    public void setStatus(Status status) {
//        this.status.set(status);
//    }
//    
//   
//    public String toFileString() {
//        return getId() + "," + getTitle() + "," + getAuthor() + "," + getStatus();
//    }
//    public StringProperty titleProperty() {    return title;  }
//    public StringProperty authorProperty() {   return author; }
//    public ObjectProperty<Status> statusProperty() {
//        return status;
//    }


