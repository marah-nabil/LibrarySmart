
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.Book;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Comparator;
import java.util.List;
import javafx.application.Platform;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.stereotype.Component;


@Component
public class BooksController {
    
    
    
    @FXML private TextField titleField;
    @FXML private TextField authorField;
    @FXML private ComboBox<Book.Status> statusCombo;
    @FXML private TableView<Book> booksTable;
     
    @FXML private TableColumn<Book, Number> idCol;
     @FXML private TableColumn<Book, String> titleCol;
     @FXML private TableColumn<Book, String> authorCol;
     @FXML private TableColumn<Book, Book.Status> statusCol;
     
    @FXML private TextField searchField;
    @FXML private ComboBox<String> sortCombo; //Title Author Status
    @FXML private Label totalBooksLabel;
    
    private MainController mainController;
    private ObservableList<Book> booksData;
    private FilteredList<Book> filteredBooks;
    private SortedList<Book> sortedBooks;
    
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = new Gson();
    private static final String API_URL = "http://localhost:9090/books";

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }
    @FXML
    public void initialize() {
        // Initialize status combo box
        statusCombo.getItems().addAll(Book.Status.AVAILABLE, Book.Status.BORROWED);
        statusCombo.setValue(Book.Status.AVAILABLE);
        
        idCol.setCellValueFactory(c -> c.getValue().idProperty());
        titleCol.setCellValueFactory(c -> c.getValue().titleProperty());
        authorCol.setCellValueFactory(c -> c.getValue().authorProperty());
        statusCol.setCellValueFactory(c -> c.getValue().statusProperty());
    
        booksTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection , newSelection) -> {
            if(newSelection != null){
                Platform.runLater(() -> {
                    titleField.setText(newSelection.getTitle());
                    authorField.setText(newSelection.getAuthor());
                    statusCombo.setValue(newSelection.getStatus());
                });
            }
        });
        sortCombo.getItems().addAll("ID","Title","Author","Status");
        sortCombo.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldValue, newValue) -> applyManualSort(newValue));
        
        searchField.textProperty().addListener((obs, oldValue, newValue) -> handleSearch(null));
        loadBooksFromApi();
    }
    
    public void loadBooksFromApi() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .GET()
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            List<Book> list = gson.fromJson(response.body(), new TypeToken<List<Book>>(){}.getType());
            booksData = FXCollections.observableArrayList(list);
            //search
            filteredBooks = new FilteredList<>(booksData, p -> true);
            //الفرز
            sortedBooks = new SortedList<>(filteredBooks);
            sortedBooks.comparatorProperty().bind(booksTable.comparatorProperty());
            Platform.runLater(() -> booksTable.setItems(booksData));

            updateTotalBooksLabel();
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Connection Error", "Cannot connect to the API!");
        }
        
    }
    
    @FXML
    private void handleAddBook() {
         String title = titleField.getText().trim();
         String author = authorField.getText().trim();
         Book.Status status = statusCombo.getValue();
        
        if (title.isEmpty() || author.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields!");
            return;
        }
        
        try {
            String json = String.format("""
                {
                  "title": "%s",                
                  "author": "%s",
                  "status": "%s"
                }
            """, title, author, status.name());
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            
            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(response -> {
                        System.out.println("Added: "+ response.body());
                        loadBooksFromApi();
                        });
                 showAlert(Alert.AlertType.INFORMATION, "Success", "Book added success!");
                        clearFields();
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add book!");
        }
    }
    @FXML
    private void handleUpdateBook() {
        Book selected = booksTable.getSelectionModel().getSelectedItem();
        if(selected == null){
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a book to update!");
            return;
        }
        
         String title = titleField.getText().trim();
         String author = authorField.getText().trim();
         Book.Status status = statusCombo.getValue();
               
         if (title.isEmpty() || author.isEmpty() || status == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields!");
            return;
        }
        
        try {
            String json = String.format("""
                {
                  "title": "%s",                
                  "author": "%s",
                  "status": "%s"
                }
            """, title, author, status.name());
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL + "/"+selected.getId()))
                    .header("Content-Type", "application/json")
                    .PUT(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            
            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(response -> Platform.runLater(() -> {
                        loadBooksFromApi();
                        clearFields();
                        showAlert(Alert.AlertType.INFORMATION, "Success", "Book updated success!");
                    }));
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add book!");
        }
    }
    @FXML
    private void handleDeleteBook() {
        Book selected = booksTable.getSelectionModel().getSelectedItem();
        if(selected == null){
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a book to delete!");
            return;
        }
                
        try {

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL + "/" + selected.getId()))
                    .DELETE()
                    .build();
            
            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(response -> {
                        System.out.println("Deleted: "+ response.body());
                        loadBooksFromApi();
                    });
            showAlert(Alert.AlertType.INFORMATION, "Success", "Book Deleted success!");
            clearFields();
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete book!");
        }
    }
    @FXML
    private void handleSearch(ActionEvent event) {
        String q = searchField.getText().trim().toLowerCase();
        
        filteredBooks.setPredicate(book ->
            q.isEmpty() ||
            book.getTitle().toLowerCase().contains(q) ||
            book.getAuthor().toLowerCase().contains(q)
            );
       updateTotalBooksLabel();
    }
    
    @FXML
    private void handleClearSearch() {
        searchField.clear();
    }

    private void clearFields() {
        titleField.clear();
        authorField.clear();
        statusCombo.setValue(Book.Status.AVAILABLE);
    }
    
    private void updateTotalBooksLabel() {
        long total = booksData.size();
        long available = booksData.stream().filter(b -> b.getStatus() == Book.Status.AVAILABLE).count();
        long borrowed = total - available;
        totalBooksLabel.setText(total + " Total Books |"+available + " Available |"+borrowed +" Borrowed");
    }
     private void applyManualSort(String key){
        if(key == null) return;
        Comparator<Book> cmp = switch(key){
            case "ID" -> Comparator.comparing(Book::getId);
            case "Title" -> Comparator.comparing(Book::getTitle, String.CASE_INSENSITIVE_ORDER);
            case "Author" -> Comparator.comparing(Book::getAuthor, String.CASE_INSENSITIVE_ORDER);
            case "Status" -> Comparator.comparing(b -> b.getStatus().name());
            default -> null;
        };
        if(cmp != null)FXCollections.sort(booksData, cmp);
        
    }
       // Show alert dialog
    public void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
