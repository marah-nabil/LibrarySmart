
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.model;

import jakarta.persistence.*;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Column(name = "first_Name",nullable = false, length = 50)
    private String first_Name;
    
    @Column(name = "last_Name",nullable = false, length = 50)
    private String last_Name;
    
    @Column(nullable = false,unique = true, length = 50)
    private String email;
    
    @Column(nullable = false)
    private String password;

    public User() { }

    public User(String first_Name, String last_Name, String email, String password) {
        this.first_Name = first_Name;
        this.last_Name = last_Name;
        this.email = email == null ? null : email.trim().toLowerCase();
        this.password = password;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return first_Name;
    }

    public void setFirstName(String first_Name) {
        this.first_Name = first_Name;
    }

    public String getLastName() {
        return last_Name;
    }

    public void setLastName(String lastName) {
        this.last_Name = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email== null ? null : email.trim().toLowerCase();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", email=" + email + '}';
    }

    // JavaFX properties for table binding
    public SimpleIntegerProperty idProperty() {
        return new SimpleIntegerProperty(id);
    }

    public SimpleStringProperty firstNameProperty() {
        return new SimpleStringProperty(first_Name);
    }

    public SimpleStringProperty lastNameProperty() {
        return new SimpleStringProperty(last_Name);
    }

    public SimpleStringProperty emailProperty() {
        return new SimpleStringProperty(email);
    }
}
