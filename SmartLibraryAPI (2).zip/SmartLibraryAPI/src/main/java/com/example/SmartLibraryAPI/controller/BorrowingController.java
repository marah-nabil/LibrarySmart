
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.controller;


import com.example.SmartLibraryAPI.model.Book;
import com.example.SmartLibraryAPI.model.Borrowing;
import com.example.SmartLibraryAPI.model.Member;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.util.ArrayList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.*;

import java.util.List;
import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import org.springframework.stereotype.Component;

@Component
public class BorrowingController {

    @FXML private ComboBox<Book> bookCombo;
    @FXML private ComboBox<Member> memberCombo;
    @FXML private DatePicker datePicker;
    
    @FXML private TableView<Borrowing> borrowingsTable;
     @FXML private TableColumn<Borrowing, Number> idCol;
     @FXML private TableColumn<Borrowing, String> bookCol;
     @FXML private TableColumn<Borrowing, String> memberCol;
     @FXML private TableColumn<Borrowing, String> borrowDateCol;
     @FXML private TableColumn<Borrowing, String> returnDateCol;
   
     @FXML private Label totalBorrowingsLabel;
    private MainController mainController;

    private ObservableList<Borrowing> borrowingsDate;
    
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = LocalDateAdapter.buildGson();
    private static final String API_URL = "http://localhost:9090/borrowing";
    private static final String BOOKS_API = "http://localhost:9090/books";
    private static final String MEMBERS_API = "http://localhost:9090/members";


    @FXML
    public void initialize() {

        idCol.setCellValueFactory(c -> c.getValue().idProperty());
        bookCol.setCellValueFactory(c  -> new SimpleObjectProperty<>
                (c.getValue().getBook() != null ?
                c.getValue().getBook().getTitle() : "-"));
        memberCol.setCellValueFactory(c  -> new SimpleObjectProperty<>
                (c.getValue().getMember() != null ?
                c.getValue().getMember().getName() : "-"));
        
        // Set up combo box renderers
        bookCombo.setCellFactory(param -> new ListCell<Book>() {
            @Override
            protected void updateItem(Book item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getTitle() + " by " + item.getAuthor());
            }
        });

        bookCombo.setButtonCell(new ListCell<Book>() {
            @Override
            protected void updateItem(Book item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getTitle() + " by " + item.getAuthor());
            }
        });

        memberCombo.setCellFactory(param -> new ListCell<Member>() {
            @Override
            protected void updateItem(Member item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getName() + " (" + item.getContact() + ")");
            }
        });

        memberCombo.setButtonCell(new ListCell<Member>() {
            @Override
            protected void updateItem(Member item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getName() + " (" + item.getContact() + ")");
            }
        });
        borrowDateCol.setCellValueFactory(c -> new SimpleObjectProperty<>(
            c.getValue().getBorrowDate() != null ? c.getValue().getBorrowDate().toString() : ""));
        returnDateCol.setCellValueFactory(c -> new SimpleObjectProperty<>(
            c.getValue().getReturnDate() != null ? c.getValue().getReturnDate().toString() : "Not returned"));
        
        datePicker.setValue(LocalDate.now());
        loadsBookAndMember();
        loadBorrowingFromApi();
    }

    public void loadsBookAndMember() {
        try {
         HttpRequest booksReq = HttpRequest.newBuilder()
                    .uri(URI.create(BOOKS_API))
                    .GET()
                    .build();
        HttpRequest membersReq = HttpRequest.newBuilder()
                    .uri(URI.create(MEMBERS_API))
                    .GET()
                    .build();
       
        HttpResponse<String> booksRes = httpClient.send(booksReq, HttpResponse.BodyHandlers.ofString());
        HttpResponse<String> membersRes = httpClient.send(membersReq, HttpResponse.BodyHandlers.ofString());
            
        List<Book> books = gson.fromJson(booksRes.body(), new TypeToken<List<Book>>(){}.getType());
        List<Member> members = gson.fromJson(membersRes.body(), new TypeToken<List<Member>>(){}.getType());
        
        Platform.runLater(() -> bookCombo.setItems(FXCollections.observableArrayList(books)));
        Platform.runLater(() -> memberCombo.setItems(FXCollections.observableArrayList(members)));
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    //تحميل جميع العمليات الاستعارة
    public void loadBorrowingFromApi() {
        try {
         HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .GET()
                    .build();
       
        HttpResponse<String> response = httpClient.send(req, HttpResponse.BodyHandlers.ofString());            
           
        JsonElement json = JsonParser.parseString(response.body());
        List<Borrowing> list = new ArrayList<>();

        if(json.isJsonArray()){
            list = gson.fromJson(json, new TypeToken<List<Borrowing>>(){}.getType());
        }else if (json.isJsonObject()){
            Borrowing single = gson.fromJson(json, Borrowing.class);
            list.add(single);
        }        
        borrowingsDate = FXCollections.observableArrayList(list);
        Platform.runLater(() -> {
            borrowingsTable.setItems(borrowingsDate);
            updateTotalBorrowingsLabel();
                });
//        totalBorrowingsLabel.setText(borrowingsDate.size() + "Borrowed Records");
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBorrowBook() {
        Book selectedBook = bookCombo.getValue();
        Member selectedMember = memberCombo.getValue();
        LocalDate borrowDate = datePicker.getValue();

        if (selectedBook == null || selectedMember == null || borrowDate == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Select both abook and a member!");
            return;
        }
        
        try {
            String json = String.format("""
                {
                  "book":  {"id": %d},                
                  "member":  {"id": %d},
                  "borrowDate":  "%s"               
                }                     
                """, selectedBook.getId(), selectedMember.getId(),borrowDate);
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            
            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(r -> Platform.runLater(() -> {
                        loadBorrowingFromApi();
                        showAlert(Alert.AlertType.INFORMATION, "Success", "Borrowing added success!");
                        clearFields();
                    }));
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add Borrowing!");
        }
    }
 @FXML
    private void handleReturnBook() {
        Borrowing selected = borrowingsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Please select a borrowing record to return!");
            return;
        }
  
        try {
            String json = String.format("""
                {
                  "returnDate": "%s"                
                }
            """, LocalDate.now().toString());
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL + "/" + selected.getId() + "/return"))
                    .header("Content-Type", "application/json")
                    .PUT(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            
            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(r -> Platform.runLater(() -> {
                        loadBorrowingFromApi();
                        showAlert(Alert.AlertType.INFORMATION, "Success", "Borrowing returned success!");
                        clearFields();
                    }));
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to return book!");
        }
    }

    private void clearFields() {
        bookCombo.setValue(null);
        memberCombo.setValue(null);
        datePicker.setValue(LocalDate.now());
    }

    private void updateTotalBorrowingsLabel() {
        long activeBorrowings = borrowingsDate.stream()
                .filter(borrowing -> borrowing.getReturnDate() == null)
                .count();
        totalBorrowingsLabel.setText(activeBorrowings + " Active Borrowings");
    }

    private void showError(String msg) {
        new Alert(Alert.AlertType.ERROR, msg).showAndWait();
    }
    private void showInfo(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
    }
    public void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }
    
}
