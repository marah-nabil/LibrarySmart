
//مرح نبيل سليم سلامة 
//220222441

package com.example.SmartLibraryAPI.controller;

import com.example.SmartLibraryAPI.model.Member;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Comparator;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import java.util.List;
import javafx.application.Platform;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import org.springframework.stereotype.Component;


@Component
public class MembersController {

    @FXML private TextField nameField;
    @FXML private TextField contactField;
    @FXML private TableView<Member> membersTable;
     @FXML private TableColumn<Member, Number> idCol;
     @FXML private TableColumn<Member, String> nameCol;
     @FXML private TableColumn<Member, String> contactCol;
     
    @FXML private TextField searchField;
    @FXML private ComboBox<String> sortCombo; //Name Id Contact
    @FXML private Label totalMembersLabel;
    
    private MainController mainController;
    private ObservableList<Member> membersData;
    private FilteredList<Member> filteredMembers;
    private SortedList<Member> sortedMembers;
    
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = new Gson();
    private static final String API_URL = "http://localhost:9090/members";

    
    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }
    
    
    @FXML
    public void initialize() {
        
        idCol.setCellValueFactory(c -> c.getValue().idProperty());
        nameCol.setCellValueFactory(c -> c.getValue().nameProperty());
        contactCol.setCellValueFactory(c -> c.getValue().contactProperty());
    
        membersTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection , newSelection) -> {
            if(newSelection != null){
                Platform.runLater(() -> {
                    nameField.setText(newSelection.getName());
                    contactField.setText(newSelection.getContact());
                });
            }
        });
        sortCombo.getItems().addAll("ID","Name","Contact");
        sortCombo.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> applyManualSort(newValue));

        loadMembersFromApi();
        
        searchField.textProperty().addListener((obs, oldValue, newValue) -> handleSearch(null));
       }

    public void loadMembersFromApi() {
                
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .GET()
                    .build();
            
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            List<Member> list = gson.fromJson(response.body(), new TypeToken<List<Member>>(){}.getType());
            membersData = FXCollections.observableArrayList(list);
            //search
            filteredMembers = new FilteredList<>(membersData, p -> true);
            //الفرز
            sortedMembers = new SortedList<>(filteredMembers);
            sortedMembers.comparatorProperty().bind(membersTable.comparatorProperty());
            membersTable.setItems(sortedMembers);

            updateTotalMembersLabel();
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Connection Error", "Cannot connect to the API!");
        }
    }

    @FXML
    private void handleAddMember() {
        
        
        final String name = nameField.getText().trim();
        final String contact = contactField.getText().trim();

        if (name.isEmpty() || contact.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields!");
            return;
        }

        try {
            String json = String.format("""
                {
                  "name": "%s",                
                  "contact": "%s"
                }
            """, name, contact);
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            
            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(response -> {
                        System.out.println("Added: "+ response.body());
                        loadMembersFromApi();
                    });
            showAlert(Alert.AlertType.INFORMATION, "Success", "Member added success!");
            clearFields();
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add Member!");
        }
    }
    @FXML
    private void handleUpdateMember() {
        Member selected = membersTable.getSelectionModel().getSelectedItem();
        if(selected == null){
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a member to update!");
            return;
        }
         
        final String name = nameField.getText().trim();
        final String contact = contactField.getText().trim();

        if (name.isEmpty() || contact.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields!");
            return;
        }

        try {
            String json = String.format("""
                {
                  "name": "%s",                
                  "contact": "%s"
                }
            """, name, contact);
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL + "/"+selected.getId()))
                    .header("Content-Type", "application/json")
                    .PUT(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            
            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(response -> Platform.runLater(() -> {
                        loadMembersFromApi();
                        clearFields();
                        showAlert(Alert.AlertType.INFORMATION, "Success", "Member updated success!");
                    }));   
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add Member!");
        }
    }
    @FXML
    private void handleDeleteMember() {
        Member selected = membersTable.getSelectionModel().getSelectedItem();
        if(selected == null){
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a member to delete!");
            return;
        }
                
        try {

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL + "/" + selected.getId()))
                    .DELETE()
                    .build();
            
            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(response -> {
                        System.out.println("Deleted: "+ response.body());
                        loadMembersFromApi();
                    });
            showAlert(Alert.AlertType.INFORMATION, "Success", "Member Deleted success!");
            clearFields();
        }catch(Exception e){
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete Member!");
        }
    }
    @FXML
    private void handleSearch(ActionEvent event) {
        String q = searchField.getText().trim().toLowerCase();
        
        filteredMembers.setPredicate(member ->
            q.isEmpty() ||
            member.getName().toLowerCase().contains(q) ||
            member.getContact().toLowerCase().contains(q)
            );
       updateTotalMembersLabel();
    }

    @FXML
    private void handleClearSearch() {
        searchField.clear();//listener عبر predicate يرجع ترو 
    }

    private void showMemberDetails(Member member) {
        if (member != null) {
            nameField.setText(member.getName());
            contactField.setText(member.getContact());
        }
    }

    private void clearFields() {
        nameField.clear();
        contactField.clear();
        membersTable.getSelectionModel().clearSelection();
    }

    private void updateTotalMembersLabel() {
        totalMembersLabel.setText(membersData.size() + " Total Members");
    }

    private void applyManualSort(String key) {
        
          if(key == null) return;
        Comparator<Member> cmp = null;
                switch(key){
                    case "ID":
                        cmp = Comparator.comparing(Member::getId);
                        break;
                    case "Name":
                        cmp = Comparator.comparing(Member::getName, String.CASE_INSENSITIVE_ORDER);
                        break;
                    case "Contact":
                        cmp = Comparator.comparing(Member::getContact, String.CASE_INSENSITIVE_ORDER);
                        break;
                }
        if(cmp != null){
            FXCollections.sort(membersData, cmp);
        }
        
    }
    public void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
