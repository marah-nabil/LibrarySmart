package smartlibrarymanager;

import java.util.Comparator;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import java.util.List;
import javafx.collections.transformation.SortedList;

public class MembersController {

    @FXML
    private TextField nameField;
    @FXML
    private TextField contactField;
    @FXML
    private TableView<Member> membersTable;
     @FXML private TableColumn<Member, Number> idCol;
     @FXML private TableColumn<Member, String> nameCol;
     @FXML private TableColumn<Member, String> conatctCol;
     
    @FXML
    private TextField searchField;
    @FXML private ComboBox<String> sortCombo; //Name Id Contact
    @FXML
    private Label totalMembersLabel;

    private MainController mainController;
    private ObservableList<Member> membersData;
    private FilteredList<Member> filteredMembers;
    private SortedList<Member> sortedMembers;
    
    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    @FXML
    public void initialize() {
        
        if (idCol != null) idCol.setCellValueFactory(c -> c.getValue().idProperty());
        if (nameCol != null) nameCol.setCellValueFactory(c -> c.getValue().nameProperty());
        if (conatctCol != null) conatctCol.setCellValueFactory(c -> c.getValue().contactProperty());
    
        // Set up table selection listener
        membersTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showMemberDetails(newValue));
    
        if(sortCombo != null){
            sortCombo.getItems().addAll("ID","Name","Contact");
            sortCombo.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> applyManualSort(newValue));
        }
    }

    public void initializeData(List<Member> members) {
                
        membersData = FXCollections.observableArrayList(members);
        
        filteredMembers = new FilteredList<>(membersData, m -> true);
        //بحث لحظي
        searchField.textProperty().addListener((observable,oldText ,newText) ->{
            final String q = newText == null ? "" : newText.trim().toLowerCase();
            filteredMembers.setPredicate(m -> {
                if(q.isEmpty()) return true;
                return m.getName().toLowerCase().contains(q) ||
                       m.getContact().toLowerCase().contains(q);
            });
        });
        //الفرز من رؤؤس الاعمدة sortedlist 
        sortedMembers = new SortedList<>(filteredMembers);
        sortedMembers.comparatorProperty().bind(membersTable.comparatorProperty());
        membersTable.setItems(sortedMembers);
        
        updateTotalMembersLabel();
    }

    @FXML
    private void handleAddMember() {
        
        
        final String name = nameField.getText().trim();
        final String contact = contactField.getText().trim();

        if (name.isEmpty() || contact.isEmpty()) {
            mainController.showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields!");
            return;
        }

        // Check for duplicate member
        boolean exists = membersData.stream().anyMatch(m -> m.getName().equalsIgnoreCase(name) && m.getContact().equalsIgnoreCase(contact));
        if (exists) {
            mainController.showAlert(Alert.AlertType.ERROR, "Error", "Member already exists (same name & contact)!");
            return;
        }
        

        // Add new member
        int newId = membersData.stream().mapToInt(Member::getId).max().orElse(0)+1;
        
        Member newMember = new Member(newId, name, contact);
        membersData.add(newMember);
        if (mainController != null) mainController.setMembers(membersData);

        mainController.showAlert(Alert.AlertType.INFORMATION, "Success", "Member added successfully!");
        clearFields();
        updateTotalMembersLabel();
    }

    @FXML
    private void handleSearch() {
        String searchText = searchField.getText().toLowerCase();
        filteredMembers.setPredicate(member -> {
            if (searchText == null || searchText.isEmpty()) {
                return true;
            }
            return member.getName().toLowerCase().contains(searchText)
                    || member.getContact().toLowerCase().contains(searchText);
        });
    }

    @FXML
    private void handleClearSearch() {
        searchField.clear();//listener عبر predicate يرجع ترو 
        //filteredMembers.setPredicate(null);
    }

    private void showMemberDetails(Member member) {
        if (member != null) {
            nameField.setText(member.getName());
            contactField.setText(member.getContact());
        }
    }

    private void clearFields() {
        nameField.clear();
        contactField.clear();
        membersTable.getSelectionModel().clearSelection();
    }

    private void updateTotalMembersLabel() {
        totalMembersLabel.setText(membersData.size() + " Total Members");
    }

    private void applyManualSort(String key) {
        
          if(key == null) return;
        Comparator<Member> cmp = null;
                switch(key){
                    case "ID":
                        cmp = Comparator.comparing(Member::getId);
                        break;
                    case "Name":
                        cmp = Comparator.comparing(Member::getName, String.CASE_INSENSITIVE_ORDER);
                        break;
                    case "Contact":
                        cmp = Comparator.comparing(Member::getContact, String.CASE_INSENSITIVE_ORDER);
                        break;
                }
        if(cmp != null){
            FXCollections.sort(membersData, cmp);
        }
        
    }
}
