package smartlibrarymanager;

import javafx.beans.property.*;
import java.util.Objects;

public class Book {
    
    public enum Status { AVAILABLE , BORROWED }

    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty title = new SimpleStringProperty();
    private final StringProperty author = new SimpleStringProperty();
    private final ObjectProperty<Status> status = new SimpleObjectProperty<>();
    
    public Book(int id, String title, String author, Status status) {
        this.id.set(id);
        this.title.set(title);
        this.author.set(author);
        this.status.set(status);
    }

    // Getters and setters
    public int getId() {
        return id.get();
    }
    public void setId(int value) {
        id.set(value);
    }
    public String getTitle() {
        return title.get();
    }
    public void setTitle(String value) {
        title.set(value);
    }
    public String getAuthor() {
        return author.get();
    }
    public void setAuthor(String value) {
        author.set(value);
    }
    public Status getStatus() {
        return status.get();
    }
    public void setStatus(Status value) {
        status.set(value);
    }

    public String toFileString() {
        return getId() + "," + getTitle() + "," + getAuthor() + "," + getStatus();
    }

    // JavaFX properties for table binding
    public IntegerProperty idProperty() {
        return id;
    }

    public StringProperty titleProperty() {
        return title;
    }

    public StringProperty authorProperty() {
        return author;
    }

    public ObjectProperty<Status> statusProperty() {
        return status;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Book)) {
            return false;
        }
        return getId() == ((Book) obj).getId();
    }
    
    public static Status parseStatus(String parts) {
        if(parts == null) return Status.AVAILABLE;
        String v = parts.trim().toLowerCase();
       
        switch (v) {
            case "available":
            case "avail":
            case "a":
                    return  Status.AVAILABLE;
            case "borrowed":
            case "borrow":
            case "b":
                    return Status.BORROWED;
            default :
                try { 
                    return Status.valueOf(parts.trim().toUpperCase()); 
                }catch(Exception e) { 
                    return Status.AVAILABLE; 
                }
            
        }
    }
}
