package smartlibrarymanager;

import java.util.Comparator;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import java.util.List;
import javafx.collections.transformation.SortedList;

public class BooksController {
    
    @FXML private TextField titleField;
    @FXML private TextField authorField;
    @FXML private ComboBox<Book.Status> statusCombo;
    @FXML private TableView<Book> booksTable;
     
    @FXML private TableColumn<Book, Number> idCol;
     @FXML private TableColumn<Book, String> titleCol;
     @FXML private TableColumn<Book, String> authorCol;
     @FXML private TableColumn<Book, Book.Status> statusCol;
     
    @FXML private TextField searchField;
    @FXML private ComboBox<String> sortCombo; //Title Author Status
    @FXML private Label totalBooksLabel;
    
    private MainController mainController;
    private ObservableList<Book> booksData;
    private FilteredList<Book> filteredBooks;
    private SortedList<Book> sortedBooks;
    
    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }
    
    @FXML
    public void initialize() {
        // Initialize status combo box
        statusCombo.getItems().addAll(Book.Status.AVAILABLE, Book.Status.BORROWED);
        statusCombo.setValue(Book.Status.AVAILABLE);
        
        idCol.setCellValueFactory(c -> c.getValue().idProperty());
        titleCol.setCellValueFactory(c -> c.getValue().titleProperty());
        authorCol.setCellValueFactory(c -> c.getValue().authorProperty());
        statusCol.setCellValueFactory(c -> c.getValue().statusProperty());
    
        // Set up table selection listener
        booksTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showBookDetails(newValue));
        
        //الفرز اليدوي
        if(sortCombo != null){
            sortCombo.getItems().addAll("ID","Title","Author","Status");
            sortCombo.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> applyManualSort(newValue));
        }
    }
    
    public void initializeData(List<Book> books) {
        booksData = FXCollections.observableArrayList(books);
        //search
        filteredBooks = new FilteredList<>(booksData, p -> true);
        searchField.textProperty().addListener((observable,oldText ,newText) ->{
            final String q = newText == null ? "" : newText.trim().toLowerCase();
            filteredBooks.setPredicate(book -> {
                if(q.isEmpty()) return true;
                return book.getTitle().toLowerCase().contains(q) ||
                       book.getAuthor().toLowerCase().contains(q);
            });
        });
        //الفرز
        sortedBooks = new SortedList<>(filteredBooks);
        sortedBooks.comparatorProperty().bind(booksTable.comparatorProperty());
        booksTable.setItems(sortedBooks);
       
        updateTotalBooksLabel();
    }
    
    @FXML
    private void handleAddBook() {
        final String title = titleField.getText().trim();
        final String author = authorField.getText().trim();
        final Book.Status status = statusCombo.getValue();
        
        if (title.isEmpty() || author.isEmpty()) {
            mainController.showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields!");
            return;
        }
        
        // Check for duplicate title
        boolean exists = booksData.stream().anyMatch(b -> b.getTitle().equalsIgnoreCase(title) && b.getAuthor().equalsIgnoreCase(author));
        if (exists) {
            mainController.showAlert(Alert.AlertType.ERROR, "Error", "A book with this title already exists!");
            return;
        }
        
        // Add new book
        int newId = booksData.stream().mapToInt(Book::getId).max().orElse(0)+1;
        Book newBook = new Book(newId, title, author, status);
        booksData.add(newBook);
        if (mainController != null) mainController.setBooks(booksData);
        
        mainController.showAlert(Alert.AlertType.INFORMATION, "Success", "Book added successfully!");
        clearFields();
        updateTotalBooksLabel();
    }
    
    @FXML
    private void handleSearch() {
        String q = searchField.getText();
        searchField.setText(q);
//        String searchText = searchField.getText().toLowerCase();
//        filteredBooks.setPredicate(book -> {
//            if (searchText == null || searchText.isEmpty()) {
//                return true;
//            }
//            return book.getTitle().toLowerCase().contains(searchText) ||
//                   book.getAuthor().toLowerCase().contains(searchText);
//        });
    }
    
    @FXML
    private void handleClearSearch() {
        searchField.clear();
       // filteredBooks.setPredicate(null);
    }
    
    private void showBookDetails(Book book) {
        if (book != null) {
            titleField.setText(book.getTitle());
            authorField.setText(book.getAuthor());
            statusCombo.setValue(book.getStatus());
        }
    }
    
    private void clearFields() {
        titleField.clear();
        authorField.clear();
        statusCombo.setValue(Book.Status.AVAILABLE);
        booksTable.getSelectionModel().clearSelection();
    }
    
    private void updateTotalBooksLabel() {
        long total = booksData.size();
        long available = booksData.stream().filter(b -> b.getStatus() == Book.Status.AVAILABLE).count();
        long borrowed = total - available;
        totalBooksLabel.setText(total + " Total Books |"+available + " Available |"+borrowed +" Borrowed");
    }
     private void applyManualSort(String key){
        if(key == null) return;
        Comparator<Book> cmp = null;
                switch(key){
                    case "ID":
                        cmp = Comparator.comparing(Book::getId);
                        break;
                    case "Title":
                        cmp = Comparator.comparing(Book::getTitle, String.CASE_INSENSITIVE_ORDER);
                        break;
                    case "Author":
                        cmp = Comparator.comparing(Book::getAuthor, String.CASE_INSENSITIVE_ORDER);
                        break;
                    case "Status":
                        cmp = Comparator.comparing(b -> b.getStatus().name());
                        break;
                }
        if(cmp != null){
            FXCollections.sort(booksData, cmp);
        }
        
    }
}
